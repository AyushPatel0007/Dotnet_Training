﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Shopping_Website.Controllers
{
     public class BuyerController : ApiController
    {
        //Shopping_DBEntities db = new Shopping_DBEntities();

        private IProductRepository productrepository = null;
        private ICartRepository cartrepository = null;
        public BuyerController(IProductRepository _productrepository, ICartRepository _cartrepository)
        {
            productrepository = _productrepository;
            cartrepository = _cartrepository;
        }



        [HttpGet]
        [Route("Buyer/GetProductDetails")]
        public List<ProductDetail> GetProductDetails()
        {
            var res = productrepository.Getallproduct();
             return res;
                

            
        }

        [HttpPost]
        [Route("Buyer/AddToCart")]
        public IHttpActionResult AddToCart(CartDetail c)
        {
            int x = cartrepository.Addtocart(c);
            if (x == 0)
            {
                return NotFound();
            }
            return Ok(x);
        }

        [HttpGet]
        [Route("Buyer/GetAllCartDetail")]
        public IHttpActionResult GetAllCartDetail()
        {
            List<CartDetail> lst = cartrepository.Getallcartdetail();
            return Ok(lst);
        }



        [HttpGet]
        [Route("Buyer/DeleteFromCart/{id}")]
        public IHttpActionResult DeletefromCart(int id)
        {
            int x = cartrepository.DeletefromCart(id);
            if (x == 0)
            {
                return NotFound();
             }
            return Ok(x);
        }

        [HttpPost]
        [Route("Buyer/UpdateCart")]
        public IHttpActionResult UpdateCart(CartDetail c)
        {
            int x = cartrepository.Updatecart(c);
            if (x == 0)
            {
                return NotFound();
            }
            return Ok(x);
        }
        [HttpGet]
        [Route("Buyer/GetCartDetail/{id}")]
        public IHttpActionResult GetCartDetail(int id)
        {
            return Ok(cartrepository.GetCartDetail(id));
        }


    }
}
