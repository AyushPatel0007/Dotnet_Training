﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using Shopping_Website.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Shopping_Website.Controllers
{
    
    public class HomeController : ApiController
    {
        Shopping_DBEntities db = new Shopping_DBEntities();
         private IUserRepository userrepository = null;
        public HomeController(IUserRepository _userrepository)
        {
            this.userrepository = _userrepository;
        }


        [Route("Home/Getalluser")]
        [HttpGet]
        public List<UserDetail> GetAllUser()
        {
            return userrepository.GetAllUser();
        }



        [HttpPost]
        [Route("Home/InsertData")]

        public int UserDetail(UserDetail userDetail)
        {
 
            // return userrepository.Insert(userDetail);
            db.UserDetails.Add(userDetail);
            return db.SaveChanges();
        }


        [Route("Home/GetUser/{username}")]
        [HttpGet]
        public  UserDetail GetUser(string username)
        {
            UserDetail res= db.UserDetails.FirstOrDefault(x => x.Username == username);
            return res;
        }



        [Route("Home/GetRole/{Role}")]
        [HttpGet]
        public string GetRole(int Role)
        {
            var res = db.RoleDetails.FirstOrDefault(xx => xx.Id == Role);
            
               
            return res.Name;
        }
        [Route("Home/GetRolebyName/{Role}")]
        [HttpGet]
        public int GetRole(string Role)
        {
            var res = db.RoleDetails.FirstOrDefault(xx => xx.Name == Role);


            return res.Id;
        }

        [HttpGet]
        [Route("Home/GetAllRoles")]
        public IHttpActionResult GetAllRoles()
        {
            List<RoleDetail> list = db.RoleDetails.ToList();
            return Ok(list);
        }

        ///edit profile
        [HttpGet]
        [Route("Home/SelectData/{id}")]
        public UserDetail SelectData(int id)
        {
            var res = db.UserDetails.FirstOrDefault(x => x.Id == id);
            return res;
        }

        [HttpPut]
        [Route("Home/UpdateData")]
        public void UpdateData(UserDetail item)
        {
            var res = db.UserDetails.FirstOrDefault(x => x.Id == item.Id);
            res.Username = item.Username;
            res.Email = item.Email;
            res.Password = item.Password;
            res.Address = item.Address;
            res.Contactno = item.Contactno;
            db.SaveChanges();
        }
        [HttpGet]
        [Route("Home/GetAllData")]
        public List<UserDetail> GetAllData()
        {
            var res = db.UserDetails.ToList();
            return res;
        }




    }
}
