﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using Shopping_Website.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Shopping_Website.Controllers
{
    public class SellerController : ApiController
    {
        Shopping_DBEntities db = new Shopping_DBEntities();
        private IProductRepository productrepository = null;
        private ICartRepository cartrepository = null;
        public SellerController(IProductRepository _productrepository, ICartRepository _cartrepository)
        {
            productrepository = _productrepository;
            cartrepository = _cartrepository;
        }
        [HttpPost]
        [Route("Seller/InsertData")]
        public  int InsertData(ProductDetail sp)
        {
             return productrepository.InsertData(sp);

        }

        [HttpGet]
        [Authorize(Roles ="seller")]
        [Route("Seller/DisplayData")]
        public List<ProductDetail> GetData()
        {
            return productrepository.GetData();
        }
        [HttpPut]
        [Route("Seller/UpdateData")]
        public int UpdateData(ProductDetail std)
        {

            return productrepository.UpdateData(std);

        }
        [HttpGet]
        [Route("Seller/SelectData/{id}")]
        public ProductDetail SelectData(int id)
        {
            var res = productrepository.SelectData(id);
            return res;
        }

       

    }
}
