﻿using Shopping_Website.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopping_Website.IRepository
{
    public interface IUserRepository
    {
          List<UserDetail> GetAllUser();
        //int UserDetail(UserDetail userDetail);
        //UserDetail GetUser(string username);
     }
}
