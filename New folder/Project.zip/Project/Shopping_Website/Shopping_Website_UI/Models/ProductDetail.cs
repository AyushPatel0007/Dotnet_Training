﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopping_Website_UI.Models
{
    public class ProductDetail
    {
        public int Id { get; set; }
        public int Sellerid { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public string Gender { get; set; }
        public decimal Price { get; set; }
        public int Discount { get; set; }
        public DateTime Publish { get; set; }
        public string Imageurl { get; set; }
        public string Size { get; set; }


         public virtual ICollection<CartDetail> CartDetails { get; set; }
        public virtual UserDetail UserDetail { get; set; }
    }
}