﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopping_Website.Repository
{
    public class CartRepository : ICartRepository
    {
        Shopping_DBEntities db = new Shopping_DBEntities();

        public int Addtocart(CartDetail c)
        {
            var res = db.CartDetails.FirstOrDefault(x => x.Customerid == c.Customerid && x.Productid == c.Productid);
            if (res != null)
            {
                res.Quantity += c.Quantity;

            }
            else
            {
                db.CartDetails.Add(c);

            }
            return db.SaveChanges();

        }

        public List<CartDetail> Getallcartdetail()
        {
            List<CartDetail> lst= db.CartDetails.ToList();
            return lst;

        }

        public List<UserDetail> Getalluserdetail()
        {
            List<UserDetail> lst = db.UserDetails.Include("ProductDetail").ToList();
            return lst;

        }
        public List<GetCartDetail_Result> GetCartDetail(int id)
        {
            return db.GetCartDetail().Where(x => x.Customerid == id).ToList();
        }



        public int DeletefromCart(int id)
        {
            var res= db.CartDetails.FirstOrDefault(x=>x.Id==id);
            db.CartDetails.Remove(res);
            return db.SaveChanges();
        }


        public int Updatecart(CartDetail c)
        {
            var res= db.CartDetails.FirstOrDefault(x => x.Id == c.Id);
            res.Quantity = c.Quantity;
            return db.SaveChanges();
        }

    }
}