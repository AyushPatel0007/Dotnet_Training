﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopping_Website.Repository
{
    public class UserRepository: IUserRepository
    {
        Shopping_DBEntities db = new Shopping_DBEntities();
        public List<UserDetail> GetAllUser()
        {
            return db.UserDetails.ToList();
        }

    }
}