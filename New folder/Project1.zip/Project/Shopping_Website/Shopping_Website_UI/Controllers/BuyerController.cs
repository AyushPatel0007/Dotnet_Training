﻿using Newtonsoft.Json;
using Shopping_Website_UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.SessionState;

namespace Shopping_Website_UI.Controllers
{
    //custom error redirect to error page

    [HandleError]

    public class BuyerController : Controller
    {
             


        //Buyer/Index
        //index page of buyer show tg eproduct detail
        public ActionResult Index()
        {
            string res = Session["token"].ToString();

            if (Session["token"] != null)
            {
                return View();
            }
            throw new Exception();
        }

        //for ajax call
        public JsonResult GetProducts()
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Add("Content-type:Application/json");
                    webClient.Headers.Add("Accept:/");
                    string str = Session["token"].ToString();
                    webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());

                    string s = webClient.DownloadString("https://localhost:44307/Buyer/GetProductDetails");
                    List<ProductDetail> lst = JsonConvert.DeserializeObject<List<ProductDetail>>(s);
                    return Json(lst, JsonRequestBehavior.AllowGet);


                }
            }

            catch (Exception e)
            {
                throw new Exception("Invalid Data Added");
            }
        }

        //pass all the product detail to dropdown
        [Route("FilterData")]
        public JsonResult GetProductx()
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Add("Content-type:Application/json");
                    webClient.Headers.Add("Accept:/");
                    string str = Session["token"].ToString();
                    webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());

                    string s = webClient.DownloadString("https://localhost:44307/Buyer/GetProductDetails");
                    List<ProductDetail> lst = JsonConvert.DeserializeObject<List<ProductDetail>>(s);
                      var lstt = lst.Select(x => new { x.Name, x.Gender, x.Category, x.Size }).ToList();
                    return Json(lst,JsonRequestBehavior.AllowGet);


                }
            }
            catch (Exception e)
            {
                throw new Exception("Invalid Data Added");
            }
        }



        //Add product in the cart
        public ActionResult AddinCart(int id)
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    CartDetail cd = new CartDetail();
                    cd.Productid = id;
                    cd.Quantity = 1;
                    cd.Customerid = Convert.ToInt32(Session["id"]);
                    webClient.Headers.Add("Content-type:Application/json");
                    webClient.Headers.Add("Accept:*/*");
                    string str = Session["token"].ToString();
                    webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());

                    string s = webClient.UploadString("https://localhost:44307/Buyer/AddToCart", "POST", JsonConvert.SerializeObject(cd));
                    int result = JsonConvert.DeserializeObject<int>(s);

                    if (result == 0)
                    {
                        
                        TempData["update"] = "Not deleted";
                        return RedirectToAction("AddToCart");
                    }
                    return RedirectToAction("AddToCart");


                }
            }
            catch (Exception e)
            {
                throw new Exception("Invalid Action Performed");
            }


        }


        //Buyer/AddToCart
        //View Page of the AddtoCart
        [HttpGet]
        public ActionResult AddToCart()
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {

                    webClient.Headers.Add("Content-type:Application/json");
                    webClient.Headers.Add("Accept:Applictaion/json");
                    string str = Session["token"].ToString();
                    webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());
                    string s = webClient.DownloadString("https://localhost:44307/Buyer/GetCartDetail/" + Session["id"].ToString());
 
                    List<CartDetails> lst = JsonConvert.DeserializeObject<List<CartDetails>>(s);
                    return View(lst);
                }
            }
            catch (Exception e)
            {
                throw new Exception("Invalid Action Performed");
            }



        }



        
        //Delete the product from the cart
        public ActionResult DeletefromCart(int id)
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    CartDetail cd = new CartDetail();
                    webClient.Headers.Add("Content-type:Application/json");
                    webClient.Headers.Add("Accept:*/*");
                    string str = Session["token"].ToString();
                    webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());


                    string s = webClient.DownloadString("https://localhost:44307/Buyer/DeleteFromCart/" + id.ToString());
                    return RedirectToAction("AddToCart");


                }
            }
            catch (Exception e)
            {
                throw new Exception("Invalid Action Performed");
            }


        }

        //update the product values(quantity)
        public ActionResult UpdateCart(CartDetail cd)
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    cd.Customerid = Convert.ToInt32(Session["id"]);
                    webClient.Headers.Add("Content-type:Application/json");
                    webClient.Headers.Add("Accept:*/*");
                    string str = Session["token"].ToString();
                    webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());
                    string s = webClient.UploadString("https://localhost:44307/Buyer/UpdateCart", "POST", JsonConvert.SerializeObject(cd));
                    int result = JsonConvert.DeserializeObject<int>(s);
                    if (result == 0)
                    {
                        TempData["update"] = "Not Updated";
                        return RedirectToAction("AddToCart");
                    }
                    else
                    { 

                        return RedirectToAction("AddToCart");
                    }
                    
                }
            }
            catch (Exception e)
            {
                throw new Exception("Invalid Data Added");
            }


        }


        //Buyer/Profile
        //get the profile of the buyer/customer
        public ActionResult Profile()
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Add("Content-type:application/Json");
                    webClient.Headers.Add("Accept:application/Json");
                    string res = webClient.DownloadString("https://localhost:44307/Home/GetUser/" + Session["username"]);
                    var list = JsonConvert.DeserializeObject<UserDetails>(res);
                    return View(list);
                }
            }
            catch (Exception)
            {
                throw new Exception("Invalid Action Performed");
            }

        }



        //Edit the Profile
        [HttpGet]
        public ActionResult EditProfile()
        {
            try
            {
                using (WebClient webClient = new WebClient())
                {
                    webClient.Headers.Add("Content-type:application/Json");
                    webClient.Headers.Add("Accept:application/Json");
                    string res = webClient.DownloadString("https://localhost:44307/Home/SelectData/" + Session["id"].ToString());
                    return View(JsonConvert.DeserializeObject<UserDetails>(res));
                }
            }
            catch (Exception)
            {
                throw new Exception("Invalid Action Performed");
            }
        }




        [HttpPost]
        public ActionResult EditProfile(UserDetails std)
        {
            try
            {
                using (WebClient webClient = new WebClient())

                {
                    std.Id = Convert.ToInt32(Session["id"]);
                    webClient.Headers.Add("Content-type:application/Json");
                    webClient.Headers.Add("Accept:application/Json");
                    string a = webClient.UploadString("https://localhost:44307/Home/UpdateData", "PUT", JsonConvert.SerializeObject(std));
                    return RedirectToAction("EditProfile");

                }
            }
            catch (Exception)
            {
                throw new Exception("Invalid Action Performed");
            }


        }



        public ActionResult ProductPayment()
        {

            using (WebClient webClient = new WebClient())
            {
                ViewBag.list = new List<string>() { "UPI", "Card" };

                webClient.Headers.Add("Content-type:Application/json");
                webClient.Headers.Add("Accept:Applictaion/json");
                string str = Session["token"].ToString();
                webClient.Headers.Add("Authorization:Bearer " + Session["token"].ToString());
                string s = webClient.DownloadString("https://localhost:44307/Buyer/GetCartDetail/" + Session["id"].ToString());

                List<CartDetails> lst = JsonConvert.DeserializeObject<List<CartDetails>>(s);
                return View(lst);
            }

        }


    }






}