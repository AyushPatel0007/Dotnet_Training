﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Shopping_Website_UI.Models;

namespace Shopping_Website_UI.Models
{
    public class UserDetail 
    {
        public int Id { get; set; }

        [Display(Name = "User Name")]
        [Remote("CheckUserName", "Home", ErrorMessage = "User Name Already Exits")]
        [Required(ErrorMessage ="Username is Required")]
        public string Username { get; set; }

        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Invalid")]
        public string Email { get; set; }

        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$", ErrorMessage = "Invalid")]
        public string Password { get; set; }

        [RegularExpression("[0-9a-zA-Z #,-]+", ErrorMessage = "Invalid")]
        public string Address { get; set; }

        [Display(Name = "Contact Number")]
        [RegularExpression(@"\d{10}", ErrorMessage = "Enter the correct Number")]
        public Nullable<int> Contactno { get; set; }
        [Required(ErrorMessage = "Role is Required")]

        public String Role { get; set; }
        public virtual ICollection<CartDetail> CartDetails { get; set; }
         public virtual ICollection<ProductDetail> ProductDetails { get; set; }
        public virtual RoleDetail RoleDetail { get; set; }
     }
}