﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Shopping_Website_UI.Models
{
    public class UserDetails
    {
        public int Id { get; set; }
         public string Username { get; set; }
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Invalid")]
        public string Email { get; set; }
        [RegularExpression(@"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$", ErrorMessage = "Invalid")]

        public string Password { get; set; }
        [RegularExpression("[0-9a-zA-Z #,-]+", ErrorMessage = "Invalid")]

        public string Address { get; set; }
        [Display(Name = "Contact Number")]
        [RegularExpression(@"\d{10}", ErrorMessage = "Enter the correct Number")]
        public Nullable<long> Contactno { get; set; }
        public int Role { get; set; }

        public virtual ICollection<CartDetail> CartDetails { get; set; }
        public virtual ICollection<ProductDetail> ProductDetails { get; set; }
        public virtual RoleDetail RoleDetail { get; set; }
    }
}