﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Shopping_Website.Controllers
{
    [Authorize(Roles = "buyer")]
    public class BuyerController : ApiController
    {
        Shopping_DBEntities db = new Shopping_DBEntities();

        private IProductRepository productrepository = null;
        private ICartRepository cartrepository = null;
        public BuyerController(IProductRepository _productrepository, ICartRepository _cartrepository)
        {
            productrepository = _productrepository;
            cartrepository = _cartrepository;
        }



        [HttpGet]
        [Route("Buyer/GetProductDetails")]
        public IHttpActionResult GetProductDetails()
        {
            var res = productrepository.Getallproduct();
            return Ok(res);



        }

        [HttpPost]
        [Route("Buyer/AddToCart")]
        public IHttpActionResult AddToCart(CartDetail c)
        {
            int x = cartrepository.Addtocart(c);
            if (x == 0)
            {
                return NotFound();
            }
            return Ok(x);
        }

        [HttpGet]
        [Route("Buyer/GetAllCartDetail")]
        public IHttpActionResult GetAllCartDetail()
        {
            List<CartDetail> lst = cartrepository.Getallcartdetail();
            return Ok(lst);
        }



        [HttpGet]
        [Route("Buyer/DeleteFromCart/{id}")]
        public IHttpActionResult DeletefromCart(int id)
        {
            int x = cartrepository.DeletefromCart(id);
            if (x == 0)
            {
                return NotFound();
            }
            return Ok(x);
        }

        [HttpPost]
        [Route("Buyer/UpdateCart")]
        public IHttpActionResult UpdateCart(CartDetail c)
        {
            int x = cartrepository.Updatecart(c);
             
            return Ok(x);
        }
        [HttpGet]
        [Route("Buyer/GetCartDetail/{id}")]
        public IHttpActionResult GetCartDetail(int id)
        {
            return Ok(cartrepository.GetCartDetail(id));
        }

        [HttpGet]
        [Route("Buyer/CartDeletebyId/{id}")]
        public IHttpActionResult CartDeletebyId(int id)
        {
           
            var res = db.CartDetails.Where(x => x.Customerid == id).ToList();
            foreach(var CartDetail in res)
            {
                CartDetail.Visible = 2;
             }
            db.SaveChanges();
            return Ok();

        }
        [HttpGet]
        [Route("Buyer/GetCartDetailbyproductid/{id}")]
        public IHttpActionResult GetCartDetailbyproductid(int id)
        {
            CartDetail  res= cartrepository.GetCartDetailsbyproductid(id);
            return Ok(res);
        }



        [HttpGet]
       [Route("Buyer/OrderDetailbyProductId/{id}")]
        public IHttpActionResult GetOrderedCartDetailsbyproductid(int id)
        {
            return Ok(cartrepository.GetOrderedCartDetailsbyproductid(id));
        }


        //by cutsomer id is in ordered
        [HttpGet]
        [Route("Buyer/OrderDetails/{id}")]
        public  List<GetCartDetail_Result> GetCartDetailordered(int id)
        {
            var res= db.GetCartDetail().Where(x => x.Customerid == id && x.Visible == 2).ToList();
            return res;
        }
        [HttpPost]
        [Route("Buyer/Paymentdetail")]
        public  void Paymentdetail(Paymentdetail obj)
        {
            var res = db.GetCartDetail().Where(x => x.Customerid == obj.Userid&&x.Visible==1).ToList();
            int sum = 0, quant = 0;
            var user = db.UserDetails.FirstOrDefault(x => x.Id == obj.Userid);
            if (obj.Name == "")
            {
                obj.Name = user.Username;
            }
            if(obj.Address == "")
            {
                obj.Address = user.Address;
            }
            if (obj.Mobileno == null)
            {
                obj.Mobileno = 91;
            }
            obj.Productid = 1;
            foreach (var r in res)
            {
                int i = 0;
                i = Convert.ToInt32(r.Price * r.Quantity) * Convert.ToInt32(r.Discount % 100);
                sum += Convert.ToInt32(r.Price * r.Quantity) - i;
                quant += Convert.ToInt32(r.Price * r.Quantity);

            }
            obj.Quantity = quant;

            obj.Email = user.Email;
            obj.Totalamount = sum;
            DateTime now = new DateTime();
          
            db.Paymentdetails.Add(obj);
            db.SaveChanges();
            
        }

    }
}
