﻿using Shopping_Website.IRepository;
using Shopping_Website.Models;
using Shopping_Website.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Shopping_Website.Controllers
{
       
    
    public class HomeController : ApiController
    {
        //Shopping_DBEntities db = new Shopping_DBEntities();
         private IUserRepository userrepository = null;
        public HomeController(IUserRepository _userrepository)
        {
            this.userrepository = _userrepository;
        }

        [HttpGet]
        [Route("Home/Getalluser")]
        public List<UserDetail> GetAllUser()
        {
            return userrepository.GetAllUser();
        }




        [HttpPost]
        [Route("Home/InsertData")]

        public int InsertData(UserDetail userDetail)
        {
 
            // return userrepository.Insert(userDetail);
          
            return userrepository.InsertData(userDetail);
        }


        [Route("Home/GetUser/{username}")]
        [HttpGet]
        public  UserDetail GetUser(string username)
        {
           
            return  userrepository.GetUser(username); 
        }



        [Route("Home/GetRole/{Role}")]
        [HttpGet]
        public string GetRole(int Role)
        {
            
            
               
            return userrepository.GetRole(Role);
        }
        [Route("Home/GetRolebyName/{Role}")]
        [HttpGet]
        public int GetRole(string Role)
        { 
            return userrepository.GetRole(Role);
        }

        [HttpGet]
        [Route("Home/GetAllRoles")]
        public IHttpActionResult GetAllRoles()
        {
           
            return Ok(userrepository.GetAllRoles());
        }

        ///edit profile
        [HttpGet]
        [Route("Home/SelectData/{id}")]
        public IHttpActionResult SelectData(int id)
        {
            
            return Ok(userrepository.SelectData(id)); ;
        }

        [HttpPut]
        [Route("Home/UpdateData")]
        public IHttpActionResult UpdateData(UserDetail item)
        {
            
           return Ok(userrepository.UpdateData(item));
        }
        [HttpGet]
        [Route("Home/GetAllData")]
        public List<UserDetail> GetAllData()
        {
            
            return userrepository.GetAllData();
        }




    }
}
