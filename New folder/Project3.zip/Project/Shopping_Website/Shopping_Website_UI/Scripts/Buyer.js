﻿function makepayment(val) {
    var mobile = $('#PaymentMobileno').val();
    var address = $('#PaymentAddress').val();
    var name = $('#PaymentName').val();
    var upi = $('#Upiid').val();
    var card = $('#Cardno').val();

    if (mobile == null || address == "" || name == "" ) {
        $('#addresstxt').empty();
        $('#addresstxt').append("Enter Address to Deliver");
        return;
    }
     if (mobile.length != 10) {
        $('#addresstxt').empty();
        $('#addresstxt').append("Enter valid Mobile");
        return;
    }
    $("#multiCollapseExample3").collapse("hide");
    if (val == 2) {
        if (card.toString().length != 16) {
            $('#cardtxt').empty();
            $('#cardtxt').append("Enter Valid card");
            return;
        }
    }
    
   
    $.ajax({
        url: '/Buyer/MakePayment',
        datatype: 'html',
        type: 'get',
        data: { Name: name, Address: address, Mobileno: mobile, Mode: val },

        success: function (data) {
            window.location.href = "/Buyer/Index";


        },
        error: function (err) {

        }






    });
} 